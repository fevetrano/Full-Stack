// inclui o módulo http
var http = require('http');
// inclui o módulo express
var express = require('express' ) ;

require('colors');

// cria a variável app, pela qual acessaremos
// os métodos / funções existentes no framework
// express
var app = express () ;

// método use() utilizado para definir em qual
// pasta estará o conteúdo estático
app.use(express.static('./public'));

// cria o servidor
var server = http.createServer(app);

// define o número da porta que o servidor ouvirá
server.listen(1600);

// mensagem exibida no console para debug
console.log("servidor rodando. . .".rainbow);

// comando para direcionar os arquivos é: console.log('http://localhost:80/pasta/nome do arquivo');
// console.log('http://localhost:80/lab1/aulajs.html');
// console.log('http://localhost:80/lab1/copy.html');
// console.log('http://localhost:80/lab1/guess.html');
// console.log('http://localhost:80/lab1/index.html');
// console.log('http://localhost:80/lab1/projects.html');
// console.log('http://localhost:80/lab7-ex1/canvas.html');
// console.log('http://localhost:80/lab7-ex2/canvas.html');
// console.log('http://localhost:80/lab8/objeto.html');
// console.log('http://localhost:80/home.html');